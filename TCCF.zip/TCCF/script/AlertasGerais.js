document.addEventListener('DOMContentLoaded', function () {
    // Seleciona o elemento da mensagem de alerta pelo ID
    const alertElement = document.getElementById('alertMessage');

    // Verifica se a mensagem de alerta existe na página atual
    if (alertElement) {
        // Define um temporizador para começar o efeito de desaparecimento após 3 segundos
        setTimeout(function () {
            alertElement.style.opacity = '0'; // Inicia a transição de opacidade para 0
            alertElement.style.transition = 'opacity 0.5s ease-out'; // Define a transição suave

            // Define um segundo temporizador para remover o elemento após a transição de opacidade
            setTimeout(function () {
                alertElement.remove(); // Remove o elemento do DOM
            }, 500); // 500 milissegundos (0.5 segundos) para a transição
        }, 3000); // 3000 milissegundos (3 segundos) antes de iniciar o desaparecimento
    }
});