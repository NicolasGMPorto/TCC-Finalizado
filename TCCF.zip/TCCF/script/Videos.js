document.addEventListener('DOMContentLoaded', function () {
    const addVideoButton = document.getElementById('addVideoButton');
    const addVideoPanel = document.getElementById('addVideoPanel');
    const cancelAddVideoButton = document.getElementById('cancelAddVideo');

    // **Verifica se todos os elementos necessários existem antes de adicionar event listeners**
    if (addVideoButton && addVideoPanel && cancelAddVideoButton) {
        addVideoButton.addEventListener('click', function () {
            // Remove a classe 'hidden' para mostrar o painel
            addVideoPanel.classList.remove('hidden');
            // Adiciona a classe 'hidden' para ocultar o botão "Adicionar vídeo"
            addVideoButton.classList.add('hidden');
        });

        cancelAddVideoButton.addEventListener('click', function () {
            // Adiciona a classe 'hidden' para ocultar o painel
            addVideoPanel.classList.add('hidden');
            // Remove a classe 'hidden' para mostrar o botão "Adicionar vídeo" novamente
            addVideoButton.classList.remove('hidden');
        });
    } else {
        // Opcional: Para depuração, você pode logar se os elementos não foram encontrados.
        // console.warn("Um ou mais elementos para a funcionalidade do vídeo não foram encontrados:", 
        //              { addVideoButton, addVideoPanel, cancelAddVideoButton });
    }
});