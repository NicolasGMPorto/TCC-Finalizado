document.getElementById('toggleUploadFormBtn').addEventListener('click', function () {
    document.getElementById('uploadFormSection').classList.toggle('hidden');
    document.getElementById('filterSortSection').classList.add('hidden'); // Esconde a seção de filtro/ordenação
});

document.getElementById('toggleFilterSortBtn').addEventListener('click', function () {
    document.getElementById('filterSortSection').classList.toggle('hidden');
    document.getElementById('uploadFormSection').classList.add('hidden'); // Esconde a seção de upload
});

// Script para exibir o nome dos arquivos selecionados em tempo real
const fileInput = document.getElementById('arquivo_upload');
const fileNameDisplay = document.getElementById('file-name-display');

fileInput.addEventListener('change', function () {
    if (this.files.length > 0) {
        let fileNames = [];
        for (let i = 0; i < this.files.length; i++) {
            fileNames.push(this.files[i].name);
        }
        // Junta os nomes dos arquivos com ", "
        let displayText = fileNames.join(', ');

        // Opcional: Truncar nomes se forem muitos ou muito longos
        const maxLength = 80; // Defina o tamanho máximo que deseja exibir
        if (displayText.length > maxLength) {
            displayText = displayText.substring(0, maxLength - 3) + '...';
        }
        fileNameDisplay.textContent = displayText;
        fileNameDisplay.classList.add('selected');

    } else {
        // Se nenhum arquivo for selecionado (por exemplo, o usuário cancela), volta ao texto padrão
        fileNameDisplay.textContent = 'Nenhum arquivo selecionado';
        fileNameDisplay.classList.remove('selected');
    }
});

// Opcional: Script para fazer as mensagens de alerta sumirem após alguns segundos
document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 1s ease-out';
            setTimeout(function () {
                alert.remove();
            }, 1000); // Remove o elemento após a transição
        }, 5000); // Mensagem some após 5 segundos
    });
});

// Script para limpar os arquivos selecionados
document.getElementById('clearFilesBtn').addEventListener('click', function () {
    const fileInput = document.getElementById('arquivo_upload');
    const fileNameDisplay = document.getElementById('file-name-display');

    // Cria um novo input de arquivo vazio para substituir o atual e limpar a seleção
    const newFileInput = document.createElement('input');
    newFileInput.type = 'file';
    newFileInput.id = 'arquivo_upload';
    newFileInput.name = 'arquivo_upload[]';
    newFileInput.multiple = true;
    newFileInput.required = true;

    // Copia os event listeners ou reatribui, se necessário.
    // No seu caso, o listener já está no ID, então basta manter o ID.
    newFileInput.addEventListener('change', function () {
        if (this.files.length > 0) {
            let fileNames = [];
            for (let i = 0; i < this.files.length; i++) {
                fileNames.push(this.files[i].name);
            }
            let displayText = fileNames.join(', ');
            const maxLength = 80;
            if (displayText.length > maxLength) {
                displayText = displayText.substring(0, maxLength - 3) + '...';
            }
            fileNameDisplay.textContent = displayText;
            fileNameDisplay.classList.add('selected');
        } else {
            fileNameDisplay.textContent = 'Nenhum arquivo selecionado';
            fileNameDisplay.classList.remove('selected');
        }
    });

    // Substitui o input antigo pelo novo (limpo)
    fileInput.parentNode.replaceChild(newFileInput, fileInput);

    // Reseta o display do nome do arquivo
    fileNameDisplay.textContent = 'Nenhum arquivo selecionado';
    fileNameDisplay.classList.remove('selected');
});