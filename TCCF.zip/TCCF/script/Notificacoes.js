document.addEventListener('DOMContentLoaded', function () {
    fetch('NotificacoesLidas.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Atualiza visualmente a lista para mostrar notificações como lidas
                console.log('Notificações marcadas como lidas com sucesso.');
                document.querySelectorAll('.notificacao-item').forEach(item => {
                    item.classList.add('lida');
                });
                // Esconde badge de notificações
                const notificationBadge = document.querySelector('.notification-badge');
                if (notificationBadge) {
                    notificationBadge.style.display = 'none';
                }
            } else {
                console.error('Erro ao marcar notificações como lidas:', data.message);
            }
        })
        .catch(error => {
            console.error('Erro na requisição AJAX:', error);
        });
});