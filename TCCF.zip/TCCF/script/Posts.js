document.addEventListener('DOMContentLoaded', function () {
    const likeButtons = document.querySelectorAll('.like-button');

    likeButtons.forEach(button => {
        button.addEventListener('click', function () {
            const postId = this.dataset.postId;
            const isLiked = this.dataset.isLiked === 'true';
            const likeCountSpan = this.closest('.post-stats').querySelector('.like-count');
            const currentLikes = parseInt(likeCountSpan.textContent);

            fetch('Posts.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=toggle_like&post_id=${postId}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.is_liked) {
                            button.classList.add('liked');
                            likeCountSpan.textContent = currentLikes + 1;
                            button.dataset.isLiked = 'true';
                        } else {
                            button.classList.remove('liked');
                            likeCountSpan.textContent = currentLikes - 1;
                            button.dataset.isLiked = 'false';
                        }
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição AJAX:', error);
                    alert('Ocorreu um erro ao processar sua curtida. Tente novamente.');
                });
        });
    });

    const deleteButtons = document.querySelectorAll('.btn-delete-post');

    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const postId = this.dataset.postId;
            if (confirm('Tem certeza que deseja excluir esta postagem? Esta ação não pode ser desfeita.')) {
                fetch('Posts.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=delete_post&post_id=${postId}`
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            window.location.reload();
                        } else {
                            alert(data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Erro na requisição AJAX de exclusão:', error);
                        alert('Ocorreu um erro ao excluir a postagem. Tente novamente.');
                    });
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', function () {
    // ... seu código JavaScript existente ...

    const addPostButton = document.getElementById('addPostButton');
    const addPostContainer = document.getElementById('addPostContainer');
    const cancelAddPostButton = document.getElementById('cancelAddPost');

    if (addPostButton && addPostContainer) {
        addPostButton.addEventListener('click', function () {
            addPostContainer.classList.remove('hidden');
            addPostButton.classList.add('hidden'); // Oculta o botão "+" ao exibir o formulário
        });
    }

    if (cancelAddPostButton && addPostContainer && addPostButton) {
        cancelAddPostButton.addEventListener('click', function () {
            addPostContainer.classList.add('hidden');
            addPostButton.classList.remove('hidden'); // Exibe o botão "+" novamente
        });
    }
});