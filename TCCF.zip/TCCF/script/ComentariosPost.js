document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.btn-edit-comment');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const commentItem = this.closest('.comment-item');
            const commentContentWrapper = commentItem.querySelector('.comment-content-wrapper');
            const commentText = commentContentWrapper.querySelector('.comment-text');
            const editForm = commentContentWrapper.querySelector('.edit-comment-form');
            const editTextArea = editForm.querySelector('.edit-comment-textarea');

            commentText.style.display = 'none';
            editForm.style.display = 'block';
            this.style.display = 'none';

            editTextArea.value = this.dataset.commentContent;
        });
    });

    const cancelButtons = document.querySelectorAll('.btn-cancel-edit');
    cancelButtons.forEach(button => {
        button.addEventListener('click', function () {
            const commentItem = this.closest('.comment-item');
            const commentContentWrapper = commentItem.querySelector('.comment-content-wrapper');
            const commentText = commentContentWrapper.querySelector('.comment-text');
            const editForm = commentContentWrapper.querySelector('.edit-comment-form');
            const editButton = commentContentWrapper.querySelector('.btn-edit-comment');

            commentText.style.display = 'block';
            editForm.style.display = 'none';
            editButton.style.display = 'inline-block';
        });
    });
});