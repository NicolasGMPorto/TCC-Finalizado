// 1. Alterna a visibilidade da senha
function toggleSenha() {
    const senhaInput = document.getElementById('senha');
    senhaInput.type = senhaInput.type === 'password' ? 'text' : 'password';
}

// 2. Bloqueia a digitação de 'e' em campos numéricos
function bloquearE(event) {
    if (event.key === "e" || event.key === "E") {
        event.preventDefault();
    }
}

// 3. Máscara de Telefone para UX (User Experience)
function aplicarMascaraTelefone() {
    const inputTelefone = document.getElementById('telefone');
    
    if (!inputTelefone) return;

    inputTelefone.addEventListener('input', function (e) {
        let value = e.target.value.replace(/\D/g, ''); // Remove tudo que não é dígito
        
        let maskedValue = '';

        if (value.length > 0) {
            // Adiciona o parêntese de abertura
            maskedValue += '(' + value.substring(0, 2); 
        }
        if (value.length > 2) {
            // Fecha o parêntese e adiciona espaço
            maskedValue += ') ' + value.substring(2, 6);
        }
        if (value.length >= 7 && value.length <= 10) {
            // Formato 4 dígitos + hífen
            maskedValue += '-' + value.substring(6, 10);
        }
        if (value.length > 10) {
            // Formato 5 dígitos + hífen (celular)
            maskedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2, 7) + '-' + value.substring(7, 11);
        }

        e.target.value = maskedValue;
    });
}

// 4. Inicialização de scripts
document.addEventListener('DOMContentLoaded', function() {
    aplicarMascaraTelefone();
});